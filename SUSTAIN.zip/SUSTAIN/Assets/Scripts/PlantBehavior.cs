﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlantBehavior : MonoBehaviour
{
    public GameBehavior gameManager;
    public GameObject plant2;
    public GameObject plant3;

    // Start is called before the first frame update
    void Start()
    {
        gameManager = GameObject.Find("GameManager").GetComponent<GameBehavior>();
        plant2.GetComponent<SpriteRenderer>().enabled = false;
        plant3.GetComponent<SpriteRenderer>().enabled = false;
    }

    // Update is called once per frame
    void Update()
    {
        if(gameManager.level2)
        {
            plant2.GetComponent<SpriteRenderer>().enabled = true;
            plant3.GetComponent<SpriteRenderer>().enabled = true;

        }
    }
}
