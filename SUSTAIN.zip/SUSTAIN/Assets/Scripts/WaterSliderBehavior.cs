﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI; // Required when Using UI elements.


public class WaterSliderBehavior : MonoBehaviour
{
    public GameBehavior gameManager;
    public Slider mainSlider;
    public Slider slider2;
    public Slider slider3;

    // Start is called before the first frame update
    void Start()
    {
      gameManager = GameObject.Find("GameManager").GetComponent<GameBehavior>();
      mainSlider.value = gameManager.Plant1CurrentMoisture;
      slider2.gameObject.SetActive(false);
      slider3.gameObject.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
      if(gameManager.level2 && !gameManager.minigame)
      {
        mainSlider.gameObject.SetActive(true);
          slider2.gameObject.SetActive(true);
          slider3.gameObject.SetActive(true);
      }
      if(gameManager.minigame)
      {
          mainSlider.gameObject.SetActive(false);
            slider2.gameObject.SetActive(false);
            slider3.gameObject.SetActive(false);
      }
      if(mainSlider.name == "Pot1 Water Slider")
      {
        mainSlider.value = gameManager.Plant1CurrentMoisture;
      }
      else if(mainSlider.name == "Pot2 Water Slider")
      {
        mainSlider.value = gameManager.Plant2CurrentMoisture;
      }
      else if(mainSlider.name == "Pot3 Water Slider")
      {
        mainSlider.value = gameManager.Plant3CurrentMoisture;
      }


    }
}
