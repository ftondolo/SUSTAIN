﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI; // Required when Using UI elements.


public class JugSliderBehavior : MonoBehaviour
{
    public GameBehavior gameManager;
    public Slider mainSlider;

    // Start is called before the first frame update
    void Start()
    {
        gameManager = GameObject.Find("GameManager").GetComponent<GameBehavior>();
        mainSlider.value = gameManager.TotalWater;
    }

    // Update is called once per frame
    void Update()
    {
      if(gameManager.minigame == true)
      {
            mainSlider.gameObject.SetActive(false);
      }
      else
      {
        mainSlider.gameObject.SetActive(true);
      }
        mainSlider.value = gameManager.TotalWater;
    }
}
