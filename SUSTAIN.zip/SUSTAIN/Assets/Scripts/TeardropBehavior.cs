﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI; 

public class TeardropBehavior : MonoBehaviour
{
    public GameBehavior gameManager;
    int tutorial = 0;
    public GameObject drop1;
    public GameObject drop2;
    public GameObject drop3;

    // Start is called before the first frame update
    void Start()
    {
      gameManager = GameObject.Find("GameManager").GetComponent<GameBehavior>();
      
      drop2.GetComponent<SpriteRenderer>().enabled = false;
      drop3.GetComponent<SpriteRenderer>().enabled = false;
      drop1.GetComponent<SpriteRenderer>().enabled = true;
    }

    // Update is called once per frame
    void Update()
    {
      if(gameManager.level2)
        {
            drop2.GetComponent<SpriteRenderer>().enabled = true;
            drop3.GetComponent<SpriteRenderer>().enabled = true;

        }
    }

    void OnMouseDown()
    {
      if(tutorial < gameManager.Plant1MoistureMin){
        tutorial += 1;
      }
      else{
        gameManager.waterPlant = true;
      }
      gameManager.TotalWater -= 1;
      if(this.name == "Teardrop1")
      {
        gameManager.Plant1CurrentMoisture += 1;
      }
      if(this.name == "Teardrop2")
      {
        Debug.Log("inside tear2");
        gameManager.Plant2CurrentMoisture += 1;
      }
      if(this.name == "Teardrop3")
      {
        gameManager.Plant3CurrentMoisture += 1;
      } 
    }
}
