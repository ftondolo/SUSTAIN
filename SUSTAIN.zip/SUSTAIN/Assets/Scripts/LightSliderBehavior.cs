﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class LightSliderBehavior : MonoBehaviour
{
    public GameBehavior gameManager;
    public Slider mainSlider;
    public Slider slider2;
    public Slider slider3;

    // Start is called before the first frame update
    void Start()
    {
      gameManager = GameObject.Find("GameManager").GetComponent<GameBehavior>();
      mainSlider.value = gameManager.Plant1CurrentLight;
      slider2.gameObject.SetActive(false);
      slider3.gameObject.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
      if(gameManager.level2 && !gameManager.minigame)
      {
        mainSlider.gameObject.SetActive(true);
            slider2.gameObject.SetActive(true);
            slider3.gameObject.SetActive(true);
      }
      if(gameManager.minigame)
      {
          mainSlider.gameObject.SetActive(false);
            slider2.gameObject.SetActive(false);
            slider3.gameObject.SetActive(false);
      }
      if(mainSlider.name == "Pot1 Light Slider")
      {
        mainSlider.value = gameManager.Plant1CurrentLight;
      }
      else if(mainSlider.name == "Pot2 Light Slider")
      {
        mainSlider.value = gameManager.Plant2CurrentLight;
      }
      else if(mainSlider.name == "Pot3 Light Slider")
      {
        mainSlider.value = gameManager.Plant3CurrentLight;
      }
    }
}
