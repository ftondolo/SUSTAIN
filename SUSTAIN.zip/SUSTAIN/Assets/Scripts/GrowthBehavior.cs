﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GrowthBehavior : MonoBehaviour
{
    public GameBehavior gameManager;
    public GameObject rice3_lvl1;
    public GameObject rice3_lvl2;
    public GameObject rice3_lvl3;
    public GameObject rice3_lvl4;
    public GameObject rice3_lvl5;
    public GameObject hemp1_lvl1;
    public GameObject hemp1_lvl2;
    public GameObject hemp1_lvl3;
    public GameObject hemp1_lvl4;
    public GameObject hemp1_lvl5;
    public GameObject hemp2_lvl1;
    public GameObject hemp2_lvl2;
    public GameObject hemp2_lvl3;
    public GameObject hemp2_lvl4;
    public GameObject hemp2_lvl5;
    public GameObject oak1_lvl1;
    public GameObject oak1_lvl2;
    public GameObject oak1_lvl3;
    public GameObject oak1_lvl4;
    public GameObject oak1_lvl5;
    public GameObject oak2_lvl1;
    public GameObject oak2_lvl2;
    public GameObject oak2_lvl3;
    public GameObject oak2_lvl4;
    public GameObject oak2_lvl5;

    // Start is called before the first frame update
    void Start()
    {
      gameManager = GameObject.Find("GameManager").GetComponent<GameBehavior>();
      rice3_lvl1.GetComponent<SpriteRenderer>().enabled = false;
      rice3_lvl2.GetComponent<SpriteRenderer>().enabled = false;
      rice3_lvl3.GetComponent<SpriteRenderer>().enabled = false;
      rice3_lvl4.GetComponent<SpriteRenderer>().enabled = false;
      rice3_lvl5.GetComponent<SpriteRenderer>().enabled = false;
      hemp1_lvl1.GetComponent<SpriteRenderer>().enabled = false;
      hemp1_lvl2.GetComponent<SpriteRenderer>().enabled = false;
      hemp1_lvl3.GetComponent<SpriteRenderer>().enabled = false;
      hemp1_lvl4.GetComponent<SpriteRenderer>().enabled = false;
      hemp1_lvl5.GetComponent<SpriteRenderer>().enabled = false;
      hemp2_lvl1.GetComponent<SpriteRenderer>().enabled = false;
      hemp2_lvl2.GetComponent<SpriteRenderer>().enabled = false;
      hemp2_lvl3.GetComponent<SpriteRenderer>().enabled = false;
      hemp2_lvl4.GetComponent<SpriteRenderer>().enabled = false;
      hemp2_lvl5.GetComponent<SpriteRenderer>().enabled = false;
      oak1_lvl1.GetComponent<SpriteRenderer>().enabled = false;
      oak1_lvl2.GetComponent<SpriteRenderer>().enabled = false;
      oak1_lvl3.GetComponent<SpriteRenderer>().enabled = false;
      oak1_lvl4.GetComponent<SpriteRenderer>().enabled = false;
      oak1_lvl5.GetComponent<SpriteRenderer>().enabled = false;
      oak2_lvl1.GetComponent<SpriteRenderer>().enabled = false;
      oak2_lvl2.GetComponent<SpriteRenderer>().enabled = false;
      oak2_lvl3.GetComponent<SpriteRenderer>().enabled = false;
      oak2_lvl4.GetComponent<SpriteRenderer>().enabled = false;
      oak2_lvl5.GetComponent<SpriteRenderer>().enabled = false;
    }

    void UpgradeLevel(string input)
    {
      if (input == "rice"){
        if (rice3_lvl1.GetComponent<SpriteRenderer>().enabled)
        {
          rice3_lvl1.GetComponent<SpriteRenderer>().enabled = false;
          rice3_lvl2.GetComponent<SpriteRenderer>().enabled = true;
        }
        else if (rice3_lvl2.GetComponent<SpriteRenderer>().enabled)
        {
          rice3_lvl2.GetComponent<SpriteRenderer>().enabled = false;
          rice3_lvl3.GetComponent<SpriteRenderer>().enabled = true;
        }
        else if (rice3_lvl3.GetComponent<SpriteRenderer>().enabled)
        {
          rice3_lvl3.GetComponent<SpriteRenderer>().enabled = false;
          rice3_lvl4.GetComponent<SpriteRenderer>().enabled = true;
        }
        else if (rice3_lvl4.GetComponent<SpriteRenderer>().enabled)
        {
          rice3_lvl4.GetComponent<SpriteRenderer>().enabled = false;
          rice3_lvl5.GetComponent<SpriteRenderer>().enabled = true;
        }
        else
        {
          Debug.Log("Max Growth achieved");
        }
      }
      else if (input == "hemp1"){
        if (hemp1_lvl1.GetComponent<SpriteRenderer>().enabled)
        {
          hemp1_lvl1.GetComponent<SpriteRenderer>().enabled = false;
          hemp1_lvl2.GetComponent<SpriteRenderer>().enabled = true;
        }
        else if (hemp1_lvl2.GetComponent<SpriteRenderer>().enabled)
        {
          hemp1_lvl2.GetComponent<SpriteRenderer>().enabled = false;
          hemp1_lvl3.GetComponent<SpriteRenderer>().enabled = true;
        }
        else if (hemp1_lvl3.GetComponent<SpriteRenderer>().enabled)
        {
          hemp1_lvl3.GetComponent<SpriteRenderer>().enabled = false;
          hemp1_lvl4.GetComponent<SpriteRenderer>().enabled = true;
        }
        else if (hemp1_lvl4.GetComponent<SpriteRenderer>().enabled)
        {
          hemp1_lvl4.GetComponent<SpriteRenderer>().enabled = false;
          hemp1_lvl5.GetComponent<SpriteRenderer>().enabled = true;
        }
        else
        {
          Debug.Log("Max Growth achieved");
        }
      }
      else if (input == "hemp2"){
        if (hemp2_lvl1.GetComponent<SpriteRenderer>().enabled)
        {
          hemp2_lvl1.GetComponent<SpriteRenderer>().enabled = false;
          hemp2_lvl2.GetComponent<SpriteRenderer>().enabled = true;
        }
        else if (hemp2_lvl2.GetComponent<SpriteRenderer>().enabled)
        {
          hemp2_lvl2.GetComponent<SpriteRenderer>().enabled = false;
          hemp2_lvl3.GetComponent<SpriteRenderer>().enabled = true;
        }
        else if (hemp2_lvl3.GetComponent<SpriteRenderer>().enabled)
        {
          hemp2_lvl3.GetComponent<SpriteRenderer>().enabled = false;
          hemp2_lvl4.GetComponent<SpriteRenderer>().enabled = true;
        }
        else if (hemp2_lvl4.GetComponent<SpriteRenderer>().enabled)
        {
          hemp2_lvl4.GetComponent<SpriteRenderer>().enabled = false;
          hemp2_lvl5.GetComponent<SpriteRenderer>().enabled = true;
        }
        else
        {
          Debug.Log("Max Growth achieved");
        }
      }
      else if (input == "oak1"){
        if (oak1_lvl1.GetComponent<SpriteRenderer>().enabled)
        {
          oak1_lvl1.GetComponent<SpriteRenderer>().enabled = false;
          oak1_lvl2.GetComponent<SpriteRenderer>().enabled = true;
        }
        else if (oak1_lvl2.GetComponent<SpriteRenderer>().enabled)
        {
          oak1_lvl2.GetComponent<SpriteRenderer>().enabled = false;
          oak1_lvl3.GetComponent<SpriteRenderer>().enabled = true;
        }
        else if (oak1_lvl3.GetComponent<SpriteRenderer>().enabled)
        {
          oak1_lvl3.GetComponent<SpriteRenderer>().enabled = false;
          oak1_lvl4.GetComponent<SpriteRenderer>().enabled = true;
        }
        else if (oak1_lvl4.GetComponent<SpriteRenderer>().enabled)
        {
          oak1_lvl4.GetComponent<SpriteRenderer>().enabled = false;
          oak1_lvl5.GetComponent<SpriteRenderer>().enabled = true;
        }
        else
        {
          Debug.Log("Max Growth achieved");
        }
      }
      else{
        if (oak2_lvl1.GetComponent<SpriteRenderer>().enabled)
        {
          oak2_lvl1.GetComponent<SpriteRenderer>().enabled = false;
          oak2_lvl2.GetComponent<SpriteRenderer>().enabled = true;
        }
        else if (oak2_lvl2.GetComponent<SpriteRenderer>().enabled)
        {
          oak2_lvl2.GetComponent<SpriteRenderer>().enabled = false;
          oak2_lvl3.GetComponent<SpriteRenderer>().enabled = true;
        }
        else if (oak2_lvl3.GetComponent<SpriteRenderer>().enabled)
        {
          oak2_lvl3.GetComponent<SpriteRenderer>().enabled = false;
          oak2_lvl4.GetComponent<SpriteRenderer>().enabled = true;
        }
        else if (oak2_lvl4.GetComponent<SpriteRenderer>().enabled)
        {
          oak2_lvl4.GetComponent<SpriteRenderer>().enabled = false;
          oak2_lvl5.GetComponent<SpriteRenderer>().enabled = true;
        }
        else
        {
          Debug.Log("Max Growth achieved");
        }
      }
    }

    bool pot1_growing = false;
    float pot1_time;

    void check1(){
      if ((gameManager.Plant1MoistureMax > gameManager.Plant1CurrentMoisture) &&  (gameManager.Plant1CurrentMoisture > gameManager.Plant1MoistureMin) &&
          ((gameManager.Plant1LightMax > gameManager.Plant1CurrentLight) && (gameManager.Plant1CurrentLight > gameManager.Plant1LightMin)))
          {
            if(!pot1_growing){
              pot1_growing = true;
              pot1_time = Time.time;
            }
            if (Time.time - pot1_time > 5){
              pot1_growing = false;
              if (gameManager.Plant1Name == "hemp"){
                UpgradeLevel("hemp1");
              }
              else{
                UpgradeLevel("oak1");
              }
            }
          }
          else{
            pot1_growing = false;
          }
    }

    bool pot2_growing = false;
    float pot2_time;
    void check2(){
      if ((gameManager.Plant2MoistureMax > gameManager.Plant2CurrentMoisture) &&  (gameManager.Plant2CurrentMoisture > gameManager.Plant2MoistureMin) &&
          ((gameManager.Plant2LightMax > gameManager.Plant2CurrentLight) && (gameManager.Plant2CurrentLight > gameManager.Plant2LightMin)))
          {
            if(!pot2_growing){
              pot2_growing = true;
              pot2_time = Time.time;
            }
            if (Time.time - pot2_time > 5){
              pot2_growing = false;
              if (gameManager.Plant2Name == "hemp"){
                UpgradeLevel("hemp2");
              }
              else{
                UpgradeLevel("oak2");
              }
            }
          }
          else{
            pot2_growing = false;

          }
    }

    bool pot3_growing = false;
    float pot3_time;
    void check3(){
      if ((gameManager.Plant3MoistureMax > gameManager.Plant3CurrentMoisture) &&  (gameManager.Plant3CurrentMoisture > gameManager.Plant3MoistureMin) &&
          ((gameManager.Plant3LightMax > gameManager.Plant3CurrentLight) && (gameManager.Plant3CurrentLight > gameManager.Plant3LightMin)))
          {
            if(!pot3_growing){
              pot3_growing = true;
              pot3_time = Time.time;
            }
            if (Time.time - pot3_time > 5){
              pot3_growing = false;
              UpgradeLevel("rice");
            }
          }
          else{
            pot3_growing = false;

          }
    }
    // Update is called once per frame Plant1GrowthRate
    void Update()
    {
      check1();
      check2();
      check3();
    }

}
