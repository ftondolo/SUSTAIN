﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MiniBehavior : MonoBehaviour
{
    public GameBehavior gameManager;
    public GameObject tmpscore;
    public GameObject pot;
    public GameObject lvl1;
    public GameObject lvl2;
    public GameObject lvl3;
    public GameObject lvl4;
    public GameObject lvl5;
    // Start is called before the first frame update

    void Start()
    {
      gameManager = GameObject.Find("GameManager").GetComponent<GameBehavior>();
      tmpscore.GetComponent<SpriteRenderer>().enabled = false;
      pot.GetComponent<SpriteRenderer>().enabled = false;
      lvl1.GetComponent<SpriteRenderer>().enabled = false;
      lvl2.GetComponent<SpriteRenderer>().enabled = false;
      lvl3.GetComponent<SpriteRenderer>().enabled = false;
      lvl4.GetComponent<SpriteRenderer>().enabled = false;
      lvl5.GetComponent<SpriteRenderer>().enabled = false;
    }

    // Update is called once per frame
    void Update()
    {
      if (gameManager.bulb_count == 10)
      {
        UpgradeLevel();
        gameManager.bulb_count = 0;
        gameManager.sus_score -= 1;
      }
      if (gameManager.sun_count == 20)
      {
        UpgradeLevel();
        gameManager.sun_count = 0;
        gameManager.sus_score += 0.5;
      }

      void UpgradeLevel()
      {
        if (lvl1.GetComponent<SpriteRenderer>().enabled)
        {
          lvl1.GetComponent<SpriteRenderer>().enabled = false;
          lvl2.GetComponent<SpriteRenderer>().enabled = true;
        }
        else if (lvl2.GetComponent<SpriteRenderer>().enabled)
        {
          lvl2.GetComponent<SpriteRenderer>().enabled = false;
          lvl3.GetComponent<SpriteRenderer>().enabled = true;
        }
        else if (lvl3.GetComponent<SpriteRenderer>().enabled)
        {
          lvl3.GetComponent<SpriteRenderer>().enabled = false;
          lvl4.GetComponent<SpriteRenderer>().enabled = true;
        }
        else
        {
          lvl4.GetComponent<SpriteRenderer>().enabled = false;
          lvl5.GetComponent<SpriteRenderer>().enabled = true;
          gameManager.mini_comp = true;
        }
      }

    }
}
