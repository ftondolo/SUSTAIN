﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WarningBehavior : MonoBehaviour
{
    public GameBehavior gameManager;
    public GameObject warning;
    // Start is called before the first frame update
    void Start()
    {
      gameManager = GameObject.Find("GameManager").GetComponent<GameBehavior>();
      warning.GetComponent<SpriteRenderer>().enabled = false;
    }

    // Update is called once per frame
    void Update()
    {
      if(warning.name == "Temp_Warning")
      {
        if(gameManager.Temp > 100)
        {
            warning.GetComponent<SpriteRenderer>().enabled = true;
        }
        else
        {
          warning.GetComponent<SpriteRenderer>().enabled = false;
        }
        
      }
      
      if(warning.name == "CO2_Warning")
      {
        if(gameManager.CO2 > 400)
        {
          warning.GetComponent<SpriteRenderer>().enabled = true;
        }
        else
        {
          warning.GetComponent<SpriteRenderer>().enabled = false;
        }
      }
    
      if(warning.name == "Water_Warning_p1")
      {
        if(gameManager.Plant1CurrentMoisture > gameManager.Plant1MoistureMax ||
          gameManager.Plant1CurrentMoisture < gameManager.Plant1MoistureMin)
        {
            warning.GetComponent<SpriteRenderer>().enabled = true;
        }
        else
        {
          warning.GetComponent<SpriteRenderer>().enabled = false;
        }
      }

      if(warning.name == "Water_Warning_p2" && gameManager.level2)
      {
        if(gameManager.Plant2CurrentMoisture > gameManager.Plant2MoistureMax ||
          gameManager.Plant2CurrentMoisture < gameManager.Plant2MoistureMin)
          {
              warning.GetComponent<SpriteRenderer>().enabled = true;
          }
          else
          {
            warning.GetComponent<SpriteRenderer>().enabled = false;
          }
      }

      if(warning.name == "Water_Warning_p3" && gameManager.level2)
      {
        if(gameManager.Plant3CurrentMoisture > gameManager.Plant3MoistureMax ||
          gameManager.Plant3CurrentMoisture < gameManager.Plant3MoistureMin)
        {
          warning.GetComponent<SpriteRenderer>().enabled = true;
        }
        else
        {
          warning.GetComponent<SpriteRenderer>().enabled = false;
        }
      }
    }
}
