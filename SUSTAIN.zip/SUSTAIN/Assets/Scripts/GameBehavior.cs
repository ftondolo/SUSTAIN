﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameBehavior : MonoBehaviour
{
/* GLOBAL */
    private double _sustainabilityScore = 9.0; //(number for in score thing)
    public double Score
    {
        get
        {
            return _sustainabilityScore;
        }
        set
        {
            _sustainabilityScore = value;
        }
    }

    private int _temperature = 65; //(var for slider)
    public int Temp
    {
        get
        {
            return _temperature;
        }
        set
        {
            _temperature = value;
        }
    }

    private int _CO2 = 250; //(var for radial)
    public int CO2
    {
        get
        {
            return _CO2;
        }
        set
        {
            _CO2 = value;
        }
    }

    private int _totalWater = 100; //(var for slider)
    public int TotalWater
    {
        get
        {
            return _totalWater;
        }
        set
        {
            _totalWater = value;
        }
    }

    private int _beans = 100; //(number for under bag)
    public int Beans
    {
        get
        {
            return _beans;
        }
        set
        {
            _beans = value;
        }
    }


    private bool _lightBadge = false;
    public bool LightBadge
    {
        get
        {
            return _lightBadge;
        }
        set
        {
            _lightBadge = value;
        }
    }

    private bool _earthBadge = false;
    public bool EarthBadge
    {
        get
        {
            return _earthBadge;
        }
        set
        {
            _earthBadge = value;
        }
    }

/* PLANT1*/
    private string _plant1Name = "";
    public string Plant1Name
    {
        get
        {
            return _plant1Name;
        }
        set
        {
            _plant1Name = value;
        }
    }

    private int _plant1MoistureMax = 30;
    public int Plant1MoistureMax
    {
        get
        {
            return _plant1MoistureMax;
        }
        set
        {
            _plant1MoistureMin = value;
        }
    }

    private int _plant1MoistureMin=10;
    public int Plant1MoistureMin
    {
        get
        {
            return _plant1MoistureMin;
        }
        set
        {
            _plant1MoistureMin = value;
        }
    }

    private int _plant1CurrentMoisture = 0; //(var for slider)
    public int Plant1CurrentMoisture
    {
        get
        {
            return _plant1CurrentMoisture;
        }
        set
        {
            _plant1CurrentMoisture = value;
        }
    }

    private int _plant1GrowthRate;
    public int Plant1GrowthRate
    {
        get
        {
            return _plant1GrowthRate;
        }
        set
        {
            _plant1GrowthRate = value;
        }
    }

    private string _plant1GrowthStage; //(string: seed, baby, teen, adult, ancient, dead)
    public string Plant1GrowthStage
    {
        get
        {
            return _plant1GrowthStage;
        }
        set
        {
            _plant1GrowthStage = value;
        }
    }

    private int _plant1LightMax;
    public int Plant1LightMax
    {
        get
        {
            return _plant1LightMax;
        }
        set
        {
            _plant1LightMax = value;
        }
    }

    private int _plant1LightMin;
    public int Plant1LightMin
    {
        get
        {
            return _plant1LightMin;
        }
        set
        {
            _plant1LightMin = value;
        }
    }

    private int _plant1CurrentLight; //(var for slider)
    public int Plant1CurrentLight
    {
        get
        {
            return _plant1CurrentLight;
        }
        set
        {
            _plant1CurrentLight = value;
        }
    }

    private int _plant1CO2rate; //(var for slider)
    public int Plant1CO2rate
    {
        get
        {
            return _plant1CO2rate;
        }
        set
        {
            _plant1CO2rate = value;
        }
    }

/* PLANT2*/
    private string _plant2Name = "";
    public string Plant2Name
    {
        get
        {
            return _plant2Name;
        }
        set
        {
            _plant2Name = value;
        }
    }

    private int _plant2MoistureMax;
    public int Plant2MoistureMax
    {
        get
        {
            return _plant2MoistureMax;
        }
        set
        {
            _plant2MoistureMax = value;
        }
    }

    private int _plant2MoistureMin;
    public int Plant2MoistureMin
    {
        get
        {
            return _plant2MoistureMin;
        }
        set
        {
            _plant2MoistureMin = value;
        }
    }

    private int _plant2CurrentMoisture = 0; //(var for slider)
    public int Plant2CurrentMoisture
    {
        get
        {
            return _plant2CurrentMoisture;
        }
        set
        {
            _plant2CurrentMoisture = value;
        }
    }

    private int _plant2GrowthRate;
    public int Plant2GrowthRate
    {
        get
        {
            return _plant2GrowthRate;
        }
        set
        {
            _plant2GrowthRate = value;
        }
    }

    private string _plant2GrowthStage; //(string: seed, baby, teen, adult, ancient, dead)
    public string Plant2GrowthStage
    {
        get
        {
            return _plant2GrowthStage;
        }
        set
        {
            _plant2GrowthStage = value;
        }
    }

    private int _plant2LightMax;
    public int Plant2LightMax
    {
        get
        {
            return _plant2LightMax;
        }
        set
        {
            _plant2LightMax = value;
        }
    }

    private int _plant2LightMin;
    public int Plant2LightMin
    {
        get
        {
            return _plant2LightMin;
        }
        set
        {
            _plant2LightMin = value;
        }
    }

    private int _plant2CurrentLight; //(var for slider)
    public int Plant2CurrentLight
    {
        get
        {
            return _plant2CurrentLight;
        }
        set
        {
            _plant2CurrentLight = value;
        }
    }

    private int _plant2CO2rate; //(var for slider)
    public int Plant2CO2rate
    {
        get
        {
            return _plant2CO2rate;
        }
        set
        {
            _plant2CO2rate = value;
        }
    }
/* PLANT3*/
    private string _plant3Name = "rice";
    public string Plant3Name
    {
        get
        {
            return _plant3Name;
        }
        set
        {
            _plant3Name = value;
        }
    }

    private int _plant3MoistureMax;
    public int Plant3MoistureMax
    {
        get
        {
            return _plant3MoistureMax;
        }
        set
        {
            _plant3MoistureMax = value;
        }
    }

    private int _plant3MoistureMin;
    public int Plant3MoistureMin
    {
        get
        {
            return _plant3MoistureMin;
        }
        set
        {
            _plant3MoistureMin = value;
        }
    }

    private int _plant3CurrentMoisture = 0; //(var for slider)
    public int Plant3CurrentMoisture
    {
        get
        {
            return _plant3CurrentMoisture;
        }
        set
        {
            _plant3CurrentMoisture = value;
        }
    }

    private int _plant3GrowthRate;
    public int Plant3GrowthRate
    {
        get
        {
            return _plant3GrowthRate;
        }
        set
        {
            _plant3GrowthRate = value;
        }
    }

    private string _plant3GrowthStage; //(string: seed, baby, teen, adult, ancient, dead)
    public string Plant3GrowthStage
    {
        get
        {
            return _plant3GrowthStage;
        }
        set
        {
            _plant3GrowthStage = value;
        }
    }

    private int _plant3LightMax;
    public int Plant3LightMax
    {
        get
        {
            return _plant3LightMax;
        }
        set
        {
            _plant3LightMax = value;
        }
    }

    private int _plant3LightMin;
    public int Plant3LightMin
    {
        get
        {
            return _plant3LightMin;
        }
        set
        {
            _plant3LightMin = value;
        }
    }

    private int _plant3CurrentLight; //(var for slider)
    public int Plant3CurrentLight
    {
        get
        {
            return _plant3CurrentLight;
        }
        set
        {
            _plant3CurrentLight = value;
        }
    }

    private int _plant3CO2rate; //(var for slider)
    public int Plant3CO2rate
    {
        get
        {
            return _plant3CO2rate;
        }
        set
        {
            _plant3CO2rate = value;
        }
    }


// Start is called before the first frame update

    public GameObject bulb;
    public GameObject sun;
    void Start()
    {
        miniBackground.gameObject.SetActive(false);
        finiBackground.gameObject.SetActive(false);
        lvl1.GetComponent<SpriteRenderer>().enabled = false;
        bulb.gameObject.SetActive(false);
        sun.gameObject.SetActive(false);
    }

// Update is called once per frame
    void Update()
    {

    }

/*onGUI start*/

    public GameObject rice_lvl;
    public GameObject oak1_lvl;
    public GameObject oak2_lvl;
    public GameObject hemp1_lvl;
    public GameObject hemp2_lvl;
    int plant_num;
    int fert_num;
    bool first_run_mini = true;
    public bool mini_comp = false;
    public string labelText = "";
    public Texture plant1;
    public Texture plant2;
    public Texture fert1;
    public GameObject lvl1;
    public GameObject lvl5;
    public GameObject pot;
    public GameObject tmpscore;
    public Texture fert2;
    public Texture earth_badge;
    public Texture light_badge;
    bool welcome = false;
    bool step1 = false;
    bool step2 = false;
    bool step3 = false;
    bool step4 = false;
    bool step5 = false;
    bool step6 = false;
    bool step7 = false;
    bool step8 = false;
    public bool waterPlant = false;
    bool step9 = false;
    bool step10 = false;
    bool step11 = false;
    public bool level2 = false;
    public int bulb_count;
    public int sun_count;
    public double sus_score = 9.0;
    bool msg_1 = false;
    bool msg_2 = false;
    bool msg_3 = false;
    public Texture lightbulb;
    public Sprite co2;
    public Texture sunlight;
    bool mini_step_1 = false;
    bool mini_step_2 = false;
    public bool minigame = false;
    public GameObject miniBackground;
    public GameObject finiBackground;
    GUIStyle beanStyle = new GUIStyle();
    GUIStyle CO2Style = new GUIStyle();
    GUIStyle scoreStyle  = new GUIStyle();
    public Slider tempSlider;
    public Slider jugSlider;
    public Slider p1SliderW;
    public Slider p1SliderL;
    public Slider p2SliderW;
    public Slider p2SliderL;
    public Slider p3SliderW;
    public Slider p3SliderL;
    public bool hasBeenClicked = false;
    bool msg_4 = false;
    bool msg_5 = false;
    public bool level3 = false;

    bool blurb1 = false;
    bool blurb2 = false;
    bool blurb3 = false;
    bool blurb4 = false;
    bool blurb5 = false;
    public GameObject mvpComplete;

    void OnGUI()
    {
        if(!minigame)
        {
            beanStyle.fontSize = 20;
            GUI.Label(new Rect(50, Screen.height-70, 150, 25), "Cacao Beans:" + _beans, beanStyle);

            CO2Style.fontSize = 35;
            GUI.Label(new Rect(Screen.width/2 + 475, 120, 150, 25), ""+_CO2+" ppm", CO2Style);

            int ones = (int)_sustainabilityScore;
            int dec = (int)((_sustainabilityScore - ones)*10);
            scoreStyle.fontSize = 45;
            GUI.Label(new Rect(Screen.width-123, 23, 150, 25), ""+ones+" . "+""+dec, scoreStyle);
        }

        GUI.Label(new Rect(Screen.width / 2 - 100, Screen.height - 50, 300, 50), labelText);

/* LEVEL1*/
        if(!welcome)
        {
            if(GUI.Button(new Rect(Screen.width/2 - 100, Screen.height/2 - 50, 200, 100), "Welcome to SUSTAIN!"+"\n" + " You are going to grow a plant!" + "\n" + "click to continue"))
            {
                welcome = true;
            }
        }

        if(welcome && !step1)
        {
            GUI.Button(new Rect(Screen.width/2 - 125, Screen.height/2 - 50, 250, 100), "First, you will choose your seed."+"\n" + "You will start with just one," + "\n" + "but later on you can unlock more...");
            if (GUI.Button(new Rect(Screen.width/2 - 125, Screen.height/2 + 50, 125, 50), plant1))
            {
                //Plant 1
                _plant1Name = "oak";
                _plant1MoistureMin = 25;
                _plant1MoistureMax = 40;
                _plant1CurrentMoisture = 0;
                _plant1LightMin = 8;
                _plant1LightMax = 12;

                //Plant 2
                _plant2Name = "hemp";
                _plant2MoistureMin = 20;
                _plant2MoistureMax = 35;
                _plant2CurrentMoisture = 25;
                _plant2LightMin = 9;
                _plant2LightMax = 15;

                step1 = true;
            }
            if (GUI.Button(new Rect(Screen.width/2, Screen.height/2 + 50, 125, 50), plant2))
            {
                //Plant 1
                _plant1Name = "hemp";
                _plant1MoistureMin = 20;
                _plant1MoistureMax = 35;
                _plant1CurrentMoisture = 0;
                _plant1LightMin = 9;
                _plant1LightMax = 15;

                //Plant 2
                _plant2Name = "oak";
                _plant2MoistureMin = 25;
                _plant2MoistureMax = 40;
                _plant2CurrentMoisture = 35;
                _plant2LightMin = 8;
                _plant2LightMax = 12;

                step1 = true;
            }
            //Plant 3
                _plant3Name = "rice";
                _plant3MoistureMin = 35;
                _plant3MoistureMax = 41;
                _plant3CurrentMoisture = 30;
                _plant3LightMin = 5;
                _plant3LightMax = 10;
        }

        if(welcome && step1 && !step2)
        {
            GUI.Button(new Rect(Screen.width/2 - 100, Screen.height/2 - 50, 200, 100), "Now, choose your fertilizer"+"\n"+"\n"+"\n" + "compost" + "   " + "fertilizer");
            if (GUI.Button(new Rect(Screen.width/2 - 125, Screen.height/2 + 50, 125, 50), fert1))
            {
                fert_num=1;
                step2 = true;
            }
            if (GUI.Button(new Rect(Screen.width/2, Screen.height/2 + 50, 125, 50), fert2))
            {
                fert_num=2;
                step2 = true;
            }
        }

        if(welcome && step1 && step2 && !step3)
        {
            if(GUI.Button(new Rect(Screen.width/2 - 175, Screen.height/2 - 50, 350, 100), "Now that you have chosen your seed and fertilizer,"+"\n" + "let’s get familiar with your garden’s features"))
            {
                step3 = true;
            }
        }

        if(welcome && step1 && step2 && step3 &&
            !step4)
        {
            if(GUI.Button(new Rect(Screen.width/2 + 100, Screen.height/2 - 300, 350, 100), "This is where you can see your sustainability score."+"\n" + "The score is on a 0-10 scale," + "\n"+"0 is bad and 10 is great."))
            {
                step4 = true;
            }
        }

        if(welcome && step1 && step2 && step3 &&
            step4 && !step5)
        {
            if(GUI.Button(new Rect(Screen.width/2 + 65, Screen.height/2 - 250, 400, 125), "This is where the amount of CO2 in the environment is displayed. "+"\n" + "We have started it at around 300ppm (parts per million)." + "\n"+"A healthy range is between 250-400ppm,"+"\n"+"but we’ll learn more about this later"+"\n"+"so don’t worry about it for now."))
            {
                step5 = true;
            }
        }

        if(welcome && step1 && step2 && step3 &&
            step4 && step5 && !step6)
        {
            if(GUI.Button(new Rect(Screen.width/2 - 175, Screen.height/2 - 250, 325, 125), "This is where you can see the"+"\n" +"temperature of the room. For now, it will" +"\n"+ "moderate itself. You can unlock this later on" + "\n"+"by playing mini-games and gaining expertise in "+"\n"+"keeping your environment balanced."))
            {
                step6 = true;
            }
        }

        if(welcome && step1 && step2 && step3 &&
            step4 && step5 && step6 && !step7)
        {
            if(GUI.Button(new Rect(Screen.width/2 + 275, Screen.height/2 - 125, 250, 100), "This is the total amount of water you"+"\n" +"have to water your plants."))
            {
                step7 = true;
            }
        }

        if(welcome && step1 && step2 && step3 &&
            step4 && step5 && step6 && step7 &&
            !step8)
        {
            GUI.Button(new Rect(Screen.width/2 + 50, Screen.height/2 + 100, 325, 125), "You use this button to give water to your plant."+"\n" +"But be careful! If you water it too much," +"\n"+ "the plant will drown and if you water it" + "\n"+"too little, the plant will die."+"\n"+"Make sure you give it a healthy amount"+"\n"+" of water. Press it now to water your plant" +"\n"+"until the warning disappears!");
            if(waterPlant)
            {
                step8 = true;
            }
        }

        if(welcome && step1 && step2 && step3 &&
            step4 && step5 && step6 && step7 &&
            step8 && waterPlant && !step9)
        {
            if(GUI.Button(new Rect(Screen.width/2 - 125, Screen.height/2 - 50, 250, 70), "Congratulations!"+"\n" +"You have earned your first badge:" +"\n"+ "the Earth Badge.") || GUI.Button(new Rect(Screen.width/2 - 75, Screen.height/2 - 150, 150, 100), earth_badge))
            {
                _earthBadge = true;
                step9 = true;
            }
        }

        if(welcome && step1 && step2 && step3 &&
            step4 && step5 && step6 && step7 &&
            step8 && waterPlant && step9 && !step10)
        {
            if(GUI.Button(new Rect(Screen.width/2 - 450, Screen.height/2 - 100, 200, 100), "You can find your badges here!"))
            {
                step10 = true;
            }
        }

        if(welcome && step1 && step2 && step3 &&
            step4 && step5 && step6 && step7 &&
            step8 && waterPlant && step9 && step10 &&
            !step11)
        {
            if(GUI.Button(new Rect(Screen.width/2 -450, Screen.height/2 + 100, 300, 100), "Also, you can find your cacao beans here. "+"\n" +"You can use these to pay for" +"\n"+ "decorations and other resources for your" + "\n"+" plants when you unlock them."))
            {
                step11 = true;
            }
        }

        if(welcome && step1 && step2 && step3 &&
            step4 && step5 && step6 && step7 &&
            step8 && waterPlant && step9 && step10 &&
            step11 && !level2)
        {
            if(GUI.Button(new Rect(Screen.width/2 - 50, Screen.height/2 - 50, 100, 100), "LEVEL 2"))
            {
                level2 = true;
                rice_lvl.GetComponent<SpriteRenderer>().enabled = true;
                if (Plant1Name == "oak"){
                  oak1_lvl.GetComponent<SpriteRenderer>().enabled = true;
                }
                if (Plant1Name == "hemp"){
                  hemp1_lvl.GetComponent<SpriteRenderer>().enabled = true;
                }
                if (Plant2Name == "hemp"){
                  hemp2_lvl.GetComponent<SpriteRenderer>().enabled = true;
                }
                if (Plant2Name == "oak"){
                  oak2_lvl.GetComponent<SpriteRenderer>().enabled = true;
                }
            }
        }

/*LEVEL2*/

        if(level2 && !msg_1)
        {
            if(GUI.Button(new Rect(Screen.width/2 - 175, Screen.height/2 - 50,350, 100), "Welcome back!"+"\n" + "Now, you are ready to learn about "+"\n" + "how different light sources affect plant growth"+"\n" + "and the environment."+"\n" + "Click here to start the minigame"))
            {
                msg_1 = true;
                miniBackground.gameObject.SetActive(true);
                minigame = true;
                _beans = 75;
                _CO2 = 360;
            }
        }

        if (level2 && !msg_2 && msg_1)
        {
            if(GUI.Button(new Rect(Screen.width/2 - 200, Screen.height/2 - 50, 400, 100), "MINI GAME."+"\n" + "You have been given a new temporary plant and environment."+"\n" + "Try to make the plant grow as much as you can by only changing"+"\n" + "the light sources while keeping a good sustainability score"))
            {
                msg_2 = true;

            }
        }

        if (level2 && msg_2 && msg_1 && !msg_3)
        {
            if(GUI.Button(new Rect(Screen.width/2 - 175, Screen.height/2 - 50, 350, 100), "The results of this minigame will not affect your garden"+"\n" + "so play around, explore the different options,"+"\n" + "and try to grow some tomatoes!"))
            {
                msg_3 = true;
            }
        }

        // in minigame

        if(level2  && msg_2 && msg_1 && msg_3 && minigame)
        {
            int ones = (int)sus_score;
            int dec = (int)((sus_score - ones)*10);
            scoreStyle.fontSize = 45;
            GUI.Label(new Rect(Screen.width-123, 23, 150, 25), ""+ones+" . "+""+dec, scoreStyle);

          if (first_run_mini)
          {
            pot.GetComponent<SpriteRenderer>().enabled = true;
            lvl1.GetComponent<SpriteRenderer>().enabled = true;
            tmpscore.GetComponent<SpriteRenderer>().enabled = true;
            first_run_mini = false;
          }
          if (GUI.Button(new Rect(Screen.width/2 + 150, Screen.height/2, 65, 65), lightbulb)){
            bulb_count += 1;
          }
          if (GUI.Button(new Rect(Screen.width/2 + 150, Screen.height/2 - 95, 65, 65), sunlight)){
            sun_count += 1;
          }
          if (mini_comp){
            if(!mini_step_1){
              if( GUI.Button(new Rect(Screen.width/2 - 100, Screen.height/2 - 50, 200, 100), "Final sustainability score: " + sus_score)){
                mini_step_1 = true;
              }
            }
            if (mini_step_1 && !mini_step_2){
              if(GUI.Button(new Rect(Screen.width/2 - 175, Screen.height/2 - 50, 350, 100), "As you may have noticed, "+"\n" + "the lightbulb will make your plants grow faster,"+"\n" + "but it is not always the most sustainable option."))
              {
                mini_step_2 = true;
              }
            }
            if (mini_step_1 && mini_step_2){
              if(GUI.Button(new Rect(Screen.width/2 - 100, Screen.height/2 - 50, 200, 100), "MINIGAME COMPLETE"))
              {
                  miniBackground.gameObject.SetActive(false);
                  pot.GetComponent<SpriteRenderer>().enabled = false;
                  lvl5.GetComponent<SpriteRenderer>().enabled = false;
                  tmpscore.GetComponent<SpriteRenderer>().enabled = false;
                  minigame = false;
                  tempSlider.gameObject.SetActive(true);
                  jugSlider.gameObject.SetActive(true);
                  p1SliderW.gameObject.SetActive(true);
                  p1SliderL.gameObject.SetActive(true);
              }
            }
          }

        }
        //out of minigame

        if(level2 && msg_2 && msg_1 && msg_3 && !minigame && !hasBeenClicked)
        {
            bulb.gameObject.SetActive(true);
            sun.gameObject.SetActive(true);


            GUI.Button(new Rect(Screen.width/2 - 180, Screen.height/2 - 275, 300, 100), "Now, you can choose a light source for"+"\n" +  "your garden. You can either pay to" +"\n" + "rent a lightbulb for 15 cacao beans a cycle"+"\n" + "or you can choose to use natural light");
        }

        if(level2 && msg_2 && msg_1 && msg_3 && !minigame && hasBeenClicked &&
            !msg_4)
        {
            if(GUI.Button(new Rect(Screen.width/2 - 125, Screen.height/2 - 50, 250, 70), "Congratulations!"+"\n" +"You have earned another badge:" +"\n"+ "the Light Badge.") || GUI.Button(new Rect(Screen.width/2 - 75, Screen.height/2 - 150, 150, 100), light_badge))
            {
                _lightBadge = true;
                msg_4 = true;
            }
        }

        if(level2 && msg_2 && msg_1 && msg_3 && !minigame && hasBeenClicked &&
            msg_4 && !msg_5 && !level3)
        {
            if(GUI.Button(new Rect(Screen.width/2 - 50, Screen.height/2 - 50, 100, 100), "LEVEL 3"))
            {
                    level3 = true;
            }
        }

if(level3 && !blurb1)
{
		if(GUI.Button(new Rect(Screen.width/2 - 125, Screen.height/2 - 50, 250, 100), "“Now that you have a light source for"+"\n" +  "your plants, the heat from the light " +"\n" + "will affect the temperature of the room. "+"\n" + "Let’s see what happens when the temperature"+"\n" +"goes up…"))
    {
    		blurb1 = true;
    }
}

//PUT IN TIME COUNTER FFOR GAMEPLAY
if(level3 && blurb1 && !blurb2)
{
		if(GUI.Button(new Rect(Screen.width/2 - 150, Screen.height/2 - 50, 300, 100), "Oh no! Looks like adding a light source"+"\n" +  "has some consequences. The temperature" +"\n" + "increases and heat is being trapped in the"+"\n" + "environment. This causes your plants to get"+"\n" +"thirsty faster."))
    {
    		blurb2 = true;
    }
}


if(level3 && blurb1 && blurb2 && !blurb3)
{
	if(GUI.Button(new Rect(Screen.width/2 - 175, Screen.height/2 - 75, 350, 150), "Artificial light uses electricity which contributes"+"\n" +  " to CO2 emissions, so using a lightbulb will add" +"\n" + "CO2 to the environment and make the temperature"+"\n" + " increase more than natural light. But, the"+"\n" +" more a plant grows, the more CO2 it consumes..."))
  {
  		blurb3 = true;
  }
}


if(level3 && blurb1 && blurb2 && blurb3 &&
		!blurb4)
{
		if(GUI.Button(new Rect(Screen.width/2 - 175, Screen.height/2 - 75, 350, 150), "Without the greenhouse effect, the Earth would not be"+"\n" +  "warm enough for humans to live. But if the greenhouse" +"\n" + "effect becomes stronger, it could make the Earth"+"\n" + "warmer than usual. Even a little extra warming may"+"\n" +"cause problems for humans, plants, and animals."))
    {
    		blurb4 = true;
    }
}


if(level3 && blurb1 & blurb2 && blurb3 &&
		blurb4 && !blurb5)
{
		if(GUI.Button(new Rect(Screen.width/2 - 175, Screen.height/2 - 75, 350, 150), "We will now give you the ability to turn your light"+"\n" +  "source on and off. Keep in mind: the longer you" +"\n" + "leave it on, the more your plants will grow but the"+"\n" + "hotter the temperature will get. If you leave it off "+"\n" +"for too long, your plants will start to die because"+"\n" +"they need light to survive. Good luck!"))
    {
    	blurb5 = true;
      tempSlider.gameObject.SetActive(false);
      jugSlider.gameObject.SetActive(false);
      p1SliderW.gameObject.SetActive(false);
      p1SliderL.gameObject.SetActive(false);
      p2SliderW.gameObject.SetActive(false);
      p2SliderL.gameObject.SetActive(false);
      p3SliderW.gameObject.SetActive(false);
      p3SliderL.gameObject.SetActive(false);
      finiBackground.gameObject.SetActive(true);
    }
}



/*end of onGUI*/
    }


}
