﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class LightBehavior : MonoBehaviour
{
    public GameBehavior gameManager;
    public GameObject sun;
    public GameObject bulb;
    int sunCounter = 0;
    int bulbCounter = 0;

    // Start is called before the first frame update
    void Start()
    {
        gameManager = GameObject.Find("GameManager").GetComponent<GameBehavior>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void OnMouseDown()
    {
        gameManager.hasBeenClicked = true;
        if(this.name == "Sun")
        {
            sunCounter++;
            if(sunCounter > 3)
            {
                sunCounter = 0;
                gameManager.Score += 0.5;
            }
            gameManager.Plant1CurrentLight+= 1;
            gameManager.Plant2CurrentLight+= 1;
            gameManager.Plant3CurrentLight+= 1;
            gameManager.Temp+=5;
        }
        else
        {
            bulbCounter++;
            if(bulbCounter > 3)
            {
                bulbCounter = 0;
                gameManager.Score -= 1;
            }
            gameManager.Plant1CurrentLight+= 2;
            gameManager.Plant2CurrentLight+= 2;
            gameManager.Plant3CurrentLight+= 2;
            gameManager.Beans-=10;
            gameManager.Temp+=10;
            gameManager.CO2+=8;
        }
    }
}
