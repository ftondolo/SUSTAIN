﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BadgeBehavior : MonoBehaviour
{
    public GameBehavior gameManager;
    public GameObject earth_badge;
    public GameObject light_badge;
    // Start is called before the first frame update
    void Start()
    {
      gameManager = GameObject.Find("GameManager").GetComponent<GameBehavior>();
      earth_badge.GetComponent<SpriteRenderer>().enabled = false;
      light_badge.GetComponent<SpriteRenderer>().enabled = false;

    }

    // Update is called once per frame
    void Update()
    {
      if (gameManager.EarthBadge){
        earth_badge.GetComponent<SpriteRenderer>().enabled = true;
      }
      if (gameManager.LightBadge){
        light_badge.GetComponent<SpriteRenderer>().enabled = true;
      }

    }
}
